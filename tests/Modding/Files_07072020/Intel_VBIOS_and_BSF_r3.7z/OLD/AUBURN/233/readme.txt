Flash Update Utility Readme.txt
2/3/98

The flash utility contained in this directory is used to update the
contents of the Video BIOS image on the Intel740 graphics option card.

The utility supports updating the Intel 28F010 128K x 8 flash device.

Using the flash update requires:

1. The flash utility, GA610.exe
2. The raw image file of the new Video BIOS, e.g. 61X-220.dat.

The utility must be run from DOS.

To run the utility from the DOS prompt:
1. Copy the files GA610.exe and 61X-XXX.dat (where XXX indicates the 
   latest version) to a floppy or to your hard drive.
2. Boot your system to a DOS command prompt.  This can be done one of
   two ways:
   a. If you are in Windows 95 or Windows 98, choose Shut Down... from
      the Start menu, then choose ReStart the Computer in MS-DOS mode
   b. If you are just booting the system, press F8 as soon as Starting
      Windows 9x... appears at the top of the screen.  When the menu 
      appears, choose Command Prompt.
3. Run the program GA610.exe from the location you saved it to.  
4. You will be prompted for the name of the Video BIOS image.  The screen
   will blank during flash update and you will be required to reboot the
   system for the changes to take effect.

If you are using a non-DOS based operating system, such as Windows NT, 
you must run the utility from a bootable floppy as described below.

To run the utility in DOS from a bootable floppy:

1. You will need to create a bootable floppy using the "sys a:" command
   from DOS.
2. Copy the files: GA610.exe, autoexec.bat, and 61X-XXX.dat to the floppy,
   where XXX is the latest bios version
3. Restart the system and it will automatically boot up and run the flash
   utility.
4. You will be prompted for the name of the Video BIOS image.  The screen
   will blank during flash update and you will be required to reboot the
   system for the changes to take effect.
